/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int fib(int);       // fibonacci recursion test 
int main ()
{
    int n;
    printf ("Input a positive integer n:\n...");
    scanf("%d", &n);
    for (int i=0; i<=n; i++)
        printf ("fib(%d)=%d \n", i, fib(i));
    return 0;
}

int fib(int n){
    if(n == 0)
        return 0;
    if(n == 1)
        return 1;
    if(n > 1)
        return fib(n-1) + fib(n-2);
}

