#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int feymann_square(int);

int main()
{
    // input the square length N for feymann squares
    int N[4];
    cout << "Input square length N in integer: " << endl;
    for (int i = 0; i <= 3; i++)
        cin >> N[i];
        
    for (int i = 0; i <= 3; i++) {       
        int square_counts = feymann_square(N[i]);
        cout << "feymann squares are: " << endl;
        cout << square_counts << endl;
    }
    return 0;
}

int feymann_square(int n){
    int count = 0;
    for (int i = n; i >= 1; i--){
        int N_sqr = pow(i, 2);
        count += N_sqr;
    }
    return count;
}

