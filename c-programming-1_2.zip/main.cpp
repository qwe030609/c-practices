#include <iostream>
#include <string>
#include <cmath>

using namespace std;

int main()
{
    float num;
    cout << "Type a number here: ";
    cin >> num;
    cout << "the number you type in is: " << num << endl;
    
    // create variables for datatypes 
    int _Num = 1;
    float _Float = 1.22;
    double _Double = 1.33;
    char _Char = 'A';
    bool _Bool = true;
    string _String = "I want to fuck you right now";
    
    // print out all data types
    cout << "int: " << _Num << endl;
    cout << "float: " << _Float << endl;
    cout << "double: " << _Double << endl;
    cout << "char: " << _Char << endl;
    cout << "bool: " << _Bool << endl;
    cout << "string: " << _String << endl;
    _String[0] = 'i';
    cout << _String << "\n";
    
    string firstName;
    cout << "Type your first name: ";
    cin >> firstName;            // Scaning a string
    cout << "Your first name is " + firstName << endl;
    
    // math function
    cout << min(1.3, 3.3);
    // cout << cos(3.14);
    std::cout << sqrt(25) << std::endl;
    std::cout << ceil(3.33) << std::endl;
    std::cout << log2(1024) << std::endl;
    
    return 0;
}
