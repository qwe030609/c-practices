#include <iostream>
using namespace std;

int main() 
{
  int age;
  cout << "How old are you?" << endl;
  cin >> age;
  
  // if else condition
  if (age > 18) {
    cout << "Eligible to Vote";
  } else if (age <= 0){
    cout << "wrong age!! you fucking moron";
  } 
  else {
    cout << "Not Eligible";
  }
  
  cout << endl;
  
  string result = (age > 18)? "Eligible to Vote":"Not Eligible";
  cout << result; 
  
  cout << endl;
  
  // while loop
  int i = 0; 
  int n = 10;
  while (i <= n){
      cout << i << " ";
      i++;
  }
  
  cout << endl;
  
  // for loop
  for (int i = 0; i <= n; i++){
      cout << i << " ";
  }
  
  return 0;
}


